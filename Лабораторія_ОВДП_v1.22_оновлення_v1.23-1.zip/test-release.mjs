import assert from 'node:assert/strict';
import fs from 'node:fs';
const app=fs.readFileSync('src/app.js','utf8');
const css=fs.readFileSync('src/style.css','utf8');
const sw=fs.readFileSync('sw.js','utf8');
const themes=['rose','peach','lavender','berry','autumn','sky','lime','emerald'];
for (const theme of themes){
  const file=`assets/themes/${theme}.webp`;
  assert.ok(fs.existsSync(file),`Немає художнього фону ${theme}`);
  const bytes=fs.readFileSync(file);
  assert.equal(bytes.toString('ascii',0,4),'RIFF',`Не WebP: ${file}`);
  assert.equal(bytes.toString('ascii',8,12),'WEBP',`Не WebP: ${file}`);
  assert.ok(css.includes(`../${file}`),`Палітра ${theme} не має фону в CSS`);
  assert.ok(sw.includes(`'./${file}'`),`Фон ${theme} не кешується офлайн`);
  assert.match(app,new RegExp(`\\['${theme}','`),`Немає палітри ${theme} в інтерфейсі`);
}
assert.match(app,/count&&k!==today&&k!==viewed/, 'Не змінювати затверджений вигляд календаря');
assert.match(app,/new Set\(events\.map\(e=>e\.id\)\)\.size} ISIN/, 'Кількість ISIN має бути в нижньому блоці');
assert.match(sw,/url\.origin!==self\.location\.origin/, 'Не кешувати сторонні API');
assert.match(app,/DB\.backup\(\)/, 'Збереження резервної копії');
assert.match(app,/DB\.restore/, 'Відновлення резервної копії');
console.log('8 фонів WebP, 8 кешованих палітр, затверджений календар, офлайн-межі, резервні копії: OK');
