import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const app=readFileSync(new URL('./src/app.js',import.meta.url),'utf8');
const css=readFileSync(new URL('./src/style.css',import.meta.url),'utf8');
assert.match(app,/count&&k!==today&&k!==viewed/);
assert.match(app,/x\.dataset\.day===b\.dataset\.day\|\|x\.classList\.contains\('today'\)/);
assert.match(app,/<span class="badge">\$\{new Set\(events\.map\(e=>e\.id\)\)\.size\} ISIN<\/span>/);
assert.match(css,/day\.selected \.count-slot,\s*#app \.calendar-grid \.day\.today \.count-slot\{visibility:hidden!important\}/);
console.log('Календар: на обраній даті лічильник прихований, кількість ISIN — у нижньому блоці.');
