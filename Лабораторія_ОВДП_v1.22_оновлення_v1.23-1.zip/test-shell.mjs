import fs from 'node:fs';import assert from 'node:assert/strict';
const html=fs.readFileSync('index.html','utf8'),sw=fs.readFileSync('sw.js','utf8');
const assets=['index.html','src/app.js','src/db.js','src/nbu.js','src/yield.js','src/forecast.js','src/compare.js','src/style.css','manifest.webmanifest','assets/icon.svg','data/nbu-snapshot.json'];
for(const file of assets){assert.ok(fs.existsSync(file),`Немає ${file}`);assert.ok(sw.includes(`'./${file}'`),`Не включено до кешу: ${file}`)}
assert.match(html,/src="\.\/src\/app\.js"/);assert.match(html,/href="\.\/src\/style\.css"/);
assert.match(sw,/self\.skipWaiting\(\)/);assert.match(sw,/self\.clients\.claim\(\)/);
assert.match(sw,/request\.mode==='navigate'/);assert.match(sw,/url\.origin!==self\.location\.origin/);
const seed=JSON.parse(fs.readFileSync('data/nbu-snapshot.json','utf8'));
assert.equal(seed.bonds.length,183);
assert.ok(seed.bonds.every(b=>Array.isArray(b.payments)&&b.id));
console.log('OK: 11 кешованих файлів, точки входу, оновлення SW, офлайн-навігація, ізоляція НБУ, 183 паспорти');
