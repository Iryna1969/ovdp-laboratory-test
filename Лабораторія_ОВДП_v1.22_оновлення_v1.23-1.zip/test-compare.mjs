import {compareBonds} from './src/compare.js';
import assert from 'node:assert/strict';
const make=(id,currency='UAH')=>({id,currency,nominal:1000,rate:15,maturity:'2028-01-01',payments:[{date:'2027-01-01',type:'Купон',amount:75},{date:'2028-01-01',type:'Купон',amount:75},{date:'2028-01-01',type:'Погашення',amount:1000}]});
const a=make('A'),b=make('B'),c=make('C');const prices=[{isin:'A',broker:'UNIVER',at:'2026-10-15T12:30',price:1050},{isin:'A',broker:'ICU',at:'2026-10-16T12:30',price:999}];
const r=compareBonds([a,b],prices,'2026-10-15');assert.equal(r.length,2);assert.equal(r[0].coupons,150);assert.equal(r[0].redemption,1000);assert.equal(r[0].total,1150);assert.equal(r[0].quote.price,1050);assert.equal(r[1].quote,null);assert.equal(r[1].ytm,null);assert.ok(Number.isFinite(r[0].ytm));
assert.throws(()=>compareBonds([a,a],prices,'2026-10-15'));assert.throws(()=>compareBonds([a,make('X','USD')],prices,'2026-10-15'));assert.equal(compareBonds([a,b,c],[], '2026-10-15').length,3);assert.throws(()=>compareBonds([a],prices,'2026-10-15'));console.log('Порівняння: 11 перевірок пройдено');
